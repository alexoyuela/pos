@echo off
chcp 65001 >nul
title El Rincon POS - Configurador de Impresora POS-58
color 0F
echo =======================================================================
echo          EL RINCÓN POS - CONFIGURAR IMPRESORA PREDETERMINADA
echo =======================================================================
echo.
echo [1/3] Desactivando administracion automatica de impresoras en Windows...
reg add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\Windows" /v "LegacyDefaultPrinterMode" /t REG_DWORD /d 1 /f >nul 2>&1
echo [OK] Modo impresora fija habilitado.
echo.
echo [2/3] Estableciendo "POS-58 (copy 1)" como predeterminada...
rundll32 printui.dll,PrintUIEntry /y /n "POS-58 (copy 1)" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$target = 'POS-58 (copy 1)'; $exact = Get-CimInstance Win32_Printer | Where-Object { $_.Name -eq $target }; if ($exact) { (Get-WmiObject -Class Win32_Printer -Filter \"Name = '$target'\").SetDefaultPrinter() | Out-Null; Write-Host ('[EXITO] Impresora predeterminada fijada a: ' + $target) -ForegroundColor Green; } else { $any = Get-CimInstance Win32_Printer | Where-Object { $_.Name -like '*POS-58*' -or $_.Name -like '*58*' -or $_.Name -like '*POS*' }; if ($any) { $alt = $any[0].Name; (Get-WmiObject -Class Win32_Printer -Filter \"Name = '$alt'\").SetDefaultPrinter() | Out-Null; Write-Host ('[AVISO] Se establecio impresora similar: ' + $alt) -ForegroundColor Yellow; } else { Write-Host '[ERROR] No se detecto ninguna impresora POS-58 instalada en Windows.' -ForegroundColor Red; } }"
echo.
echo [3/3] Verificando cola de impresion...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = (Get-CimInstance Win32_Printer | Where-Object { $_.Default -eq $true }); Write-Host ('Impresora Predeterminada Actual de Windows: ' + $p.Name) -ForegroundColor Cyan"
echo.
echo =======================================================================
echo [LISTO] Su impresora termica esta configurada.
echo.
echo [IMPORTANTE PARA ROLLO 58MM EN LUGAR DE CARTA]
echo Si la impresora imprime en blanco o avanza como si fuera hoja Carta:
echo A continuacion se abrira la ventana de 'Preferencias de Impresion'.
echo Asegurese de que en 'Tamano de Papel' este seleccionado '58mm' o 'Roll Paper 58mm'.
echo =======================================================================
echo.
echo Presione cualquier tecla para abrir las preferencias o cierre esta ventana.
pause
rundll32 printui.dll,PrintUIEntry /e /n "POS-58 (copy 1)"

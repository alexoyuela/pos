$port = 8080
$appPath = "$PSScriptRoot\app"
if (-not (Test-Path $appPath)) { $appPath = "$PSScriptRoot" }
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://127.0.0.1:$port/")
try {
    $listener.Start()
} catch {
    Write-Host "El puerto $port ya esta en uso o el servidor ya fue iniciado."
    exit
}

while ($listener.IsListening) {
    $context = $listener.GetContext()
    $request = $context.Request
    $response = $context.Response
    
    $urlPath = $request.Url.LocalPath.TrimStart('/')
    if ([string]::IsNullOrEmpty($urlPath)) { $urlPath = "index.html" }
    
    # Handle Offline Health check
    if ($urlPath -eq "api/health") {
        $jsonBytes = [System.Text.Encoding]::UTF8.GetBytes('{"status":"ok","mode":"windows-offline"}')
        $response.ContentType = "application/json; charset=utf-8"
        $response.ContentLength64 = $jsonBytes.Length
        $response.OutputStream.Write($jsonBytes, 0, $jsonBytes.Length)
        $response.Close()
        continue
    }
    
    # Handle Offline Users API
    if ($urlPath -eq "api/users" -and $request.HttpMethod -eq "GET") {
        $usersFile = Join-Path $PSScriptRoot "data\admin\Db\users.json"
        if (Test-Path $usersFile) {
            $uBytes = [System.IO.File]::ReadAllBytes($usersFile)
            $response.ContentType = "application/json; charset=utf-8"
            $response.ContentLength64 = $uBytes.Length
            $response.OutputStream.Write($uBytes, 0, $uBytes.Length)
            $response.Close()
            continue
        }
    }
    
    # Primary file resolution (first check app/, then root folder for admin/data files)
    $filePath = Join-Path $appPath $urlPath
    if (-not (Test-Path $filePath)) {
        $rootFile = Join-Path $PSScriptRoot $urlPath
        if (Test-Path $rootFile) {
            $filePath = $rootFile
        } else {
            # If requesting an asset/api that does not exist, return 404, else route to index.html for SPA
            if ($urlPath.StartsWith("api/") -or $urlPath.Contains(".")) {
                $response.StatusCode = 404
                $response.Close()
                continue
            } else {
                $filePath = Join-Path $appPath "index.html"
            }
        }
    }
    
    if (Test-Path $filePath) {
        $bytes = [System.IO.File]::ReadAllBytes($filePath)
        $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
        $mime = switch ($ext) {
            ".html" { "text/html; charset=utf-8" }
            ".js"   { "application/javascript; charset=utf-8" }
            ".mjs"  { "application/javascript; charset=utf-8" }
            ".css"  { "text/css; charset=utf-8" }
            ".json" { "application/json; charset=utf-8" }
            ".webmanifest" { "application/manifest+json; charset=utf-8" }
            ".png"  { "image/png" }
            ".jpg"  { "image/jpeg" }
            ".jpeg" { "image/jpeg" }
            ".svg"  { "image/svg+xml" }
            ".ico"  { "image/x-icon" }
            ".woff" { "font/woff" }
            ".woff2" { "font/woff2" }
            ".csv"  { "text/csv; charset=utf-8" }
            default { "application/octet-stream" }
        }
        $response.ContentType = $mime
        $response.ContentLength64 = $bytes.Length
        $response.OutputStream.Write($bytes, 0, $bytes.Length)
    } else {
        $response.StatusCode = 404
    }
    $response.Close()
}

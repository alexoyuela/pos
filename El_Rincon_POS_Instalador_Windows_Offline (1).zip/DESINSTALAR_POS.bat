@echo off
chcp 65001 >nul
title Desinstalar Acceso Directo - El Rincon POS
echo Desea eliminar el acceso directo de 'El Rincon POS' de su Escritorio?
pause
if exist "%USERPROFILE%\Desktop\El Rincon POS.lnk" (
    del "%USERPROFILE%\Desktop\El Rincon POS.lnk"
    echo Acceso directo eliminado correctamente.
) else (
    echo No se encontro el acceso directo en el escritorio.
)
pause

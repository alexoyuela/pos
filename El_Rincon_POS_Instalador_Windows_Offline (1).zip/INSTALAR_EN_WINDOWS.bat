@echo off
chcp 65001 >nul
title Instalador Windows - El Rincon POS Offline
color 0A
echo =====================================================================
echo       INSTALADOR WINDOWS - EL RINCÓN CAFE, RON & SAZÓN POS
echo =====================================================================
echo.
echo [1/3] Configurando Sistema POS para funcionamiento 100%% sin Internet...
set "ROOT_DIR=%~dp0"
set "LAUNCHER=%ROOT_DIR%INICIAR_POS_OFFLINE.bat"
set "ICON_FILE=%ROOT_DIR%icon.ico"
if not exist "%ICON_FILE%" set "ICON_FILE=%ROOT_DIR%app\icon.ico"

echo [2/3] Creando acceso directo en el Escritorio de Windows...
set "VBS_SCRIPT=%TEMP%\create_rincon_pos_shortcut.vbs"
echo Set oWS = WScript.CreateObject("WScript.Shell") > "%VBS_SCRIPT%"
echo sLinkFile = "%USERPROFILE%\Desktop\El Rincon POS.lnk" >> "%VBS_SCRIPT%"
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> "%VBS_SCRIPT%"
echo oLink.TargetPath = "%LAUNCHER%" >> "%VBS_SCRIPT%"
echo oLink.WorkingDirectory = "%ROOT_DIR%" >> "%VBS_SCRIPT%"
echo oLink.Description = "Sistema POS El Rincon Cafe, Ron & Sazon (Modo Offline)" >> "%VBS_SCRIPT%"
echo oLink.IconLocation = "%ICON_FILE%" >> "%VBS_SCRIPT%"
echo oLink.Save >> "%VBS_SCRIPT%"
cscript /nologo "%VBS_SCRIPT%"
del "%VBS_SCRIPT%"

echo.
echo [OK] Acceso directo 'El Rincon POS' creado en su Escritorio con exito!
echo.
echo [3/3] Iniciando Sistema POS en modo sin conexion...
timeout /t 2 /nobreak >nul
start "" "%LAUNCHER%"
exit

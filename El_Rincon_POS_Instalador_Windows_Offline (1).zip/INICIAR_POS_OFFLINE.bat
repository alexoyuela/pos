@echo off
chcp 65001 >nul
title El Rincon POS - Servidor Local Offline con POS-58
echo =====================================================================
echo      EL RINCÓN CAFE, RON & SAZÓN - SISTEMA POS (MODO SIN INTERNET)
echo =====================================================================
echo.
echo [1/3] Configurando impresora termica POS-58 (copy 1) como predeterminada...
reg add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\Windows" /v "LegacyDefaultPrinterMode" /t REG_DWORD /d 1 /f >nul 2>&1
rundll32 printui.dll,PrintUIEntry /y /n "POS-58 (copy 1)" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$target = 'POS-58 (copy 1)'; $exact = Get-CimInstance Win32_Printer | Where-Object { $_.Name -eq $target }; if ($exact) { (Get-WmiObject -Class Win32_Printer -Filter \"Name = '$target'\").SetDefaultPrinter() | Out-Null; Write-Host ('[OK] Impresora predeterminada: ' + $target) -ForegroundColor Green; } else { $any = Get-CimInstance Win32_Printer | Where-Object { $_.Name -like '*POS-58*' -or $_.Name -like '*58*' -or $_.Name -like '*POS*' }; if ($any) { (Get-WmiObject -Class Win32_Printer -Filter \"Name = '$($any[0].Name)'\").SetDefaultPrinter() | Out-Null; Write-Host ('[AVISO] Establecida: ' + $any[0].Name) -ForegroundColor Yellow; } }"
echo.
echo [2/3] Iniciando servidor local ultra-rapido (sin dependencias)...
start /min powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0server.ps1"

timeout /t 2 /nobreak >nul

echo [3/3] Abriendo POS en modo aplicacion de escritorio con impresion silenciosa...
set "APP_URL=http://127.0.0.1:8080"
set "PROFILE_DIR=%LOCALAPPDATA%\ElRinconPOSProfile"

:: Check Edge (Standard on Windows 10 & 11) with silent POS-58 printing
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --user-data-dir="%PROFILE_DIR%" --app=%APP_URL% --kiosk-printing --kiosk-printer-device="POS-58 (copy 1)" --force-light-mode --disable-features=WebContentsForceDark,InvertColors,AutoDarkMode
    goto end
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --user-data-dir="%PROFILE_DIR%" --app=%APP_URL% --kiosk-printing --kiosk-printer-device="POS-58 (copy 1)" --force-light-mode --disable-features=WebContentsForceDark,InvertColors,AutoDarkMode
    goto end
)

:: Check Chrome with silent POS-58 printing
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --user-data-dir="%PROFILE_DIR%" --app=%APP_URL% --kiosk-printing --kiosk-printer-device="POS-58 (copy 1)" --force-light-mode --disable-features=WebContentsForceDark,InvertColors,AutoDarkMode
    goto end
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --user-data-dir="%PROFILE_DIR%" --app=%APP_URL% --kiosk-printing --kiosk-printer-device="POS-58 (copy 1)" --force-light-mode --disable-features=WebContentsForceDark,InvertColors,AutoDarkMode
    goto end
)
if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
    start "" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" --user-data-dir="%PROFILE_DIR%" --app=%APP_URL% --kiosk-printing --kiosk-printer-device="POS-58 (copy 1)" --force-light-mode --disable-features=WebContentsForceDark,InvertColors,AutoDarkMode
    goto end
)

:: Fallback to system default browser
start "" "%APP_URL%"

:end
echo.
echo Sistema POS en ejecucion en %APP_URL%
echo Todas las ventas, mesas e impresion termica funcionan 100%% sin Internet.
exit
